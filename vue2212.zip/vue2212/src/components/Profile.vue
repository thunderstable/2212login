<template>
<body>
 
</body>
</template>

<script>
export default {
  name: 'Profile',
  computed: {
    currentUser() {
      return this.$store.state.auth.user;
    }
  },
  mounted() {
    if (!this.currentUser) {
      this.$router.push('/login');
    }
  }
};

var k=localStorage.getItem('user');
// console.log(k);
// console.log(k['accessToken']);

 window.location.assign("http://iot.sgroup.io:50080/flow/api/watertreat/?value=" + k )
 localStorage.removeItem('user');
</script>